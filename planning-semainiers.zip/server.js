const express = require('express');
const http = require('http');
const cors = require('cors');
const path = require('path');
const Database = require('better-sqlite3');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json({ limit: '2mb' }));

// === DB ===
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'planning.db');
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.prepare(`CREATE TABLE IF NOT EXISTS states (
  week_start TEXT PRIMARY KEY,
  data TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
)`).run();

function getState(week) {
  return db.prepare('SELECT week_start, data, version, updated_at FROM states WHERE week_start = ?').get(week);
}
function upsertState(week, data, expectedVersion) {
  const now = new Date().toISOString();
  const row = getState(week);
  if (!row) {
    if (expectedVersion !== 0 && expectedVersion !== undefined) {
      const err = new Error('Version mismatch on insert');
      err.code = 'VERSION_CONFLICT';
      err.latest = { version: 0, data: '{}' };
      throw err;
    }
    db.prepare('INSERT INTO states (week_start, data, version, updated_at) VALUES (?, ?, 0, ?)')
      .run(week, JSON.stringify(data), now);
    return { version: 0, data, updated_at: now };
  }
  if (expectedVersion !== row.version) {
    const err = new Error('Version mismatch');
    err.code = 'VERSION_CONFLICT';
    err.latest = { version: row.version, data: JSON.parse(row.data), updated_at: row.updated_at };
    throw err;
  }
  const nextVersion = row.version + 1;
  db.prepare('UPDATE states SET data = ?, version = ?, updated_at = ? WHERE week_start = ?')
    .run(JSON.stringify(data), nextVersion, now, week);
  return { version: nextVersion, data, updated_at: now };
}

// === API ===
app.get('/api/state', (req, res) => {
  const week = req.query.week;
  if (!week) return res.status(400).json({ error: 'Missing week (YYYY-MM-DD)' });
  const row = getState(week);
  if (!row) return res.json({ week_start: week, data: null, version: 0, updated_at: null });
  res.json({ week_start: row.week_start, data: JSON.parse(row.data), version: row.version, updated_at: row.updated_at });
});

app.put('/api/state', (req, res) => {
  const { week_start, data, version } = req.body || {};
  if (!week_start || typeof data !== 'object' || version === undefined) {
    return res.status(400).json({ error: 'Body must include week_start, data (object), version (number)' });
  }
  try {
    const out = upsertState(week_start, data, version);
    io.to(roomName(week_start)).emit('state:update', { week_start, ...out });
    res.json({ week_start, ...out });
  } catch (e) {
    if (e.code === 'VERSION_CONFLICT') {
      return res.status(409).json({ error: 'VERSION_CONFLICT', latest: e.latest });
    }
    console.error(e);
    res.status(500).json({ error: 'INTERNAL_ERROR' });
  }
});

function roomName(week) { return `week:${week}`; }

io.on('connection', (socket) => {
  socket.on('join', (week) => { socket.join(roomName(week)); });
  socket.on('leave', (week) => { socket.leave(roomName(week)); });
});

// === Serve static ===
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`✅ En ligne sur http://localhost:${PORT}`));
